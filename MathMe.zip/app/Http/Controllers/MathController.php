<?php namespace App\Http\Controllers;
use Request;
use Input;
use Auth;
use App\Score;
use DB;
use App\Askedquestions;

class MathController extends Controller {

	public function postSaveScore(Request $request)
	{
		$score = new Score;
		$score->score = Input::get('score');
		$score->user_id = Auth::user()->id;
		$score->save();
	}
	public function getScore()
	{
		$scores = DB::table('users')
            ->join('scores', 'users.id', '=', 'scores.user_id')
            ->select('users.name', 'scores.score','users.user_image')
	    ->orderBy('scores.score', 'desc')
	    ->take(10)
            ->get();
		echo json_encode($scores);
	}
	public function getHighScore()
	{
		
 		$scores = DB::table('scores')->select(DB::raw('MAX(score) as score'))->where('user_id','=',Auth::user()->id)->get();
 		if($scores[0]->score == NULL){
 			$scores[0]->score = "0";
 		}
 		
		echo json_encode($scores);
	}
	public function postAskQuestion(Request $request){

		$question =  Input::get('question');
		$asked_question = new Askedquestions();
		$asked_question->user_id = Auth::user()->id;
		$asked_question->question = $question;
		$asked_question->save();
		if(Input::get('score') != 0){
			$score = new Score;
			$score->score = Input::get('score');
			$score->user_id = Auth::user()->id;
			$score->save();
		}
		
		
		return array('result' => true );
	}
	public function getAskdedQuestionCount(){
		//DB::connection()->enableQueryLog();
		$scores = DB::table('asked_questions')
			->select(DB::raw('COUNT(question) as total_question'))
			->where('is_answered','=','0')
			->where('user_id','!=',Auth::user()->id)
            ->get();
       //  dd(DB::getQueryLog());
		echo json_encode($scores);
	}

	public function getAskdedQuestionsList(){
		
		$scores = DB::table('asked_questions')
			->select('id','question')
			->where('is_answered','=','0')
			->where('user_id','!=',Auth::user()->id)
			->take(10)
            ->get();
       
		echo json_encode($scores);
	}

	public function postAnswerQuestion(Request $request){
		$response = array('status' => 'error', 'result' => '' );
		$question =  Input::get('question');
		$answer =  Input::get('answer');
		$row = DB::table('asked_questions')
			->where('id','=',$question)
			->where('is_answered','=','0')
            ->first();
        if($row){
        	$asked_question = explode('+', $row->question);
        	$a = intval($asked_question[0]);
        	$b = intval($asked_question[1]);
        	$asked_question_answer = intval($a + $b); 
			if($asked_question_answer ==  $answer){ 
			$query_result = DB::table('asked_questions')
			->where('id','=',$question)->update(array('answer' =>  $answer ,'is_answered' => 1));
			if($query_result){
				$response['status'] = 'ok';
				$response['result'] = "Congratulation your answer is right";
			}

			} else{
				$response['result'] = "Your anwser is wrong. Please try again";
			}
        } else{
        	$response['result'] = "question is already answered.";
        }
		return $response;       
	}

	public function getAnwseredQuestionsList(){
		
		$scores = DB::table('asked_questions')
			->select('id','question','answer')
			->where('is_answered','=','1')
			->where('user_id','!=',Auth::user()->id)
			->take(20)
            ->get();
       
		echo json_encode($scores);
	}
	
	public function getUserCharacter(){
		
		$character = DB::table('users')
			->select('user_image')
			->where('id','=',Auth::user()->id)
                        ->first();
       
		echo json_encode($character);
	}
}