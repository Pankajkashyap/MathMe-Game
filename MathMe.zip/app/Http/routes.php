<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', 'HomeController@index');

Route::get('home', 'HomeController@index');

Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);
Route::post('saveScore', 'MathController@postSaveScore');
Route::get('getscore', 'MathController@getScore');
Route::get('gethighscore','MathController@getHighScore');
Route::post('askQuestion','MathController@postAskQuestion');
Route::get('getAskdedQuestionCount', 'MathController@getAskdedQuestionCount');
Route::get('getAskdedQuestionsList', 'MathController@getAskdedQuestionsList');
Route::post('answerQuestion ','MathController@postAnswerQuestion');
Route::get('getAnwseredQuestionsList', 'MathController@getAnwseredQuestionsList');
Route::get('getUserCharacter','MathController@getUserCharacter');