<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=10">
	
	<title>Math me</title>

	<link href="{{ asset('public/css/app.css') }}" rel="stylesheet">
	<link href="{{ asset('public/css/main.css') }}" rel="stylesheet">
	<script type="text/javascript" src="lib/impact/impact.js"></script>
	<script type="text/javascript" src="lib/game/main.js"></script>
	<!-- Fonts -->
	<link href='//fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>

<body>


<div class="modal fade" id="parentModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Disclaimer</h4>
      </div>
      <div class="modal-body">
		      		<h5>AIM OF THE STUDY:</h5>
		    <p>The aim of this project is to develop a digital educational game for children aged from 5 to 8 years old. The game’s objective is to engage children in play while at the same time helping them to learn the basics of maths. The game can be played on any electronic device that has a browser, e.g. a desktop computer, a laptop or a smartphone; any mobile device that a family would normally own.</p>
		<p>The goal of the game is to provide a positive learning experience for children in the early years of their education. When playing the game, the child would advance through a series of levels and as advancement is made the child could then learn some basic mathematics concepts. The game could be played alone or within a classroom setting. A socialization aspect has been added to the game so that children can anonymously help other children in the class to explore right solutions within the game.</p>

		<h5>BENEFITS OF THE STUDY: </h5>
		<p>Children naturally love to play and to learn something educational at the same time could only benefit them. Also associating education with enjoyment at an early age would be advantageous to any child. The social aspect of the game would help children to both give and receive help from other children, which would encourage co-operation and help a child to overcome a potential learning obstacle in a non-threatening manner.</p>

		<h5>WHAT WOULD BE EXPECTED OF YOUR CHILD?</h5>
		<p>All your child will be required to do is to play the game on an iPad for 5 to 10 minutes. Please be aware that it is not your child’s ability that will be tested here but rather your child will encouraged in interactive manner to learn basic mathematics.</p>
		<p>If you do decide that your child can participate in this project then be assured that his or her safety is my foremost priority. You will be present with the child throughout the play time, and the game can be played in a place of your choice.  If your child decides not, wish to participate at any time or wishes to discontinue participation during the game play that is fine.  He or she has the freedom to withdraw from participation at any time.</p>

		<h5>RISKS:</h5>
		<p>There are no identified risks associated with participating in this project. However, it is required that you be present with your child at all times during they play the game. If you have concerns about the conduct of the study please contact the development team at pnkjkshp80@gmail.com </p>

		<h5>CONFIDENTIALITY:</h5>
		<p>The data you provide will be confidential, and no identifying information will be sought. Only group data will be analysed and reported.</p>

		<h5>PARTICIPATION:</h5>
		<p>Participation of your child in this project is entirely voluntary, and you and your child are free to decline to participate. If you accept the invitation to participate, you will still have the opportunity to withdraw from the project at any stage during. Any associated data will not be used in the project. </p>

      </div>
          </div>
  </div>
</div>

	
@if (Auth::guest())
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle Navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
			</div>

			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				 <ul class="nav navbar-nav">
					<li><a href="{{ url('/') }}">Home</a></li>
				</ul> 

				<ul class="nav navbar-nav navbar-right">
					@if (Auth::guest())
						<li><a href="{{ url('/auth/login') }}">Login</a></li>
						<li><a href="{{ url('/auth/register') }}">Register</a></li>
					@else
						 <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">{{ Auth::user()->name }} <span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
								<li><a href="{{ url('/auth/logout') }}">Logout</a></li>
							</ul>
						</li> 
					@endif
				</ul>
			</div>
		</div>
	</nav>
	@else
	 <style type="text/css">#canvas{margin-top:20px;}</style>
@endif
	@yield('content')
	<script type="text/javascript" src="{{ asset('public/js/jquery.js') }}"></script>
	<script type="text/javascript" src="{{ asset('public/js/bootstrap.js') }}"></script>
	
	<!-- Scripts 
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script> -->
	<script type="text/javascript">
	$(document).ready(function(){
                
                $('#register_btn').on("click",function(e){
                	
                	
                	 $('#parentRegisterModal').modal({
                                keyboard: false
                            });
                	
                	$('#disagree').click(function(){
                	window.location = '<?php echo url(); ?>';
                	return false;
                	});
                	
                    /*if (!$('input[name=disclaimer]').is(":checked"))
                    {
                            
                        return false;
                    } */
                });
                 
            });
	$(document).ready(function(){

		var form_id = '';
		$(document).delegate('.answer_submit',"click",function(event) { 

     		event.preventDefault();
     		if($(this.form).find('input[name=answer]').val() == ''){
     			$('.result').addClass('btn-warning').html('Please enter answer first').show(800);
     			setTimeout(function(){
					$('.result').hide(800);
				},3000);
     			return false;
     		}
     		form_id = $(this.form).attr('id');
     		$.ajax({
					url: '{{url()."/answerQuestion"}}',
					method: 'POST',
					data: $(this.form).serialize(),
					success: function(data) {

						if(data.status == 'ok'){

							ig.game.score+=1000;
							ig.game.scoreDisplay.updateScore(ig.game.score);

							$('.result').removeClass('btn-warning').addClass('btn-success').html( data.result +'<p>Your score is : '+ig.game.score+' </p>').show(800);
							
							$('#'+form_id).slideUp();
							
							
						} else {
							$('.result').removeClass('btn-success').addClass('btn-warning').html( data.result ).show(800);
							
						}
						setTimeout(function(){

								$('.result').hide(800);
							},3000);
						
					}
				});
     		
		});
	});
	</script>
</body>
</html>