@extends('app')

@section('content')

<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
  Launch demo modal
</button> -->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Asked Questions</h4>
      </div>
      <div class="modal-body">
      <div class="row">
  
        <div class="col-md-12">
        	
        		<div class="result text-center alert">

        		</div>
        	</div>
    	</div>
		
        <div class="list-group" id="asked_question">
  
	</div>
		
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="answerList" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Answers List</h4>
      </div>
      <div class="modal-body">
     
    
        <div class="list-group" id="answered_question_list">
  
       </div>
    
      </div>
    </div>
  </div>
</div>
<div class="canvas_wrapper">
<canvas id="canvas"></canvas>
</div>

<!-- <div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
			<div class="panel panel-default">
				<div class="panel-heading">Home</div>

				<div class="panel-body">
					
				</div>
			</div>
		</div>
	</div>
</div> -->
@endsection