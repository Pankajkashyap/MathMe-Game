@extends('app')

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Register</div>
				<div class="panel-body">
					@if (count($errors) > 0)
						<div class="alert alert-danger">
							<strong>Whoops!</strong> There were some problems with your input.<br><br>
							<ul>
								@foreach ($errors->all() as $error)
									<li>{{ $error }}</li>
								@endforeach
							</ul>
						</div>
					@endif

					<form class="form-horizontal register" role="form" method="POST" action="{{ url('/auth/register') }}">
						
<div class="modal fade" id="parentRegisterModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="margin-top: 30px;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Disclaimer</h4>
      </div>
      <div class="modal-body">
     <h5>AIM OF THE STUDY:</h5>
<p>The aim of this project is to develop a digital educational game for children aged from 5 to 8 years old. The game’s objective is to engage children in play while at the same time helping them to learn the basics of maths. The game can be played on any electronic device that has a browser, e.g. a desktop computer, a laptop or a smartphone; any mobile device that a family would normally own.</p>
<p>The goal of the game is to provide a positive learning experience for children in the early years of their education. When playing the game, the child would advance through a series of levels and as advancement is made the child could then learn some basic mathematics concepts. The game could be played alone or within a classroom setting. A socialization aspect has been added to the game so that children can anonymously help other children in the class to explore right solutions within the game.</p>

<h5>BENEFITS OF THE STUDY: </h5>
<p>Children naturally love to play and to learn something educational at the same time could only benefit them. Also associating education with enjoyment at an early age would be advantageous to any child. The social aspect of the game would help children to both give and receive help from other children, which would encourage co-operation and help a child to overcome a potential learning obstacle in a non-threatening manner.</p>

<h5>WHAT WOULD BE EXPECTED OF YOUR CHILD?</h5>
<p>All your child will be required to do is to play the game on an iPad for 5 to 10 minutes. Please be aware that it is not your child’s ability that will be tested here but rather your child will encouraged in interactive manner to learn basic mathematics.</p>
<p>If you do decide that your child can participate in this project then be assured that his or her safety is my foremost priority. You will be present with the child throughout the play time, and the game can be played in a place of your choice.  If your child decides not, wish to participate at any time or wishes to discontinue participation during the game play that is fine.  He or she has the freedom to withdraw from participation at any time.</p>

<h5>RISKS:</h5>
<p>There are no identified risks associated with participating in this project. However, it is required that you be present with your child at all times during they play the game. If you have concerns about the conduct of the study please contact the development team at pnkjkshp80@gmail.com </p>

<h5>CONFIDENTIALITY:</h5>
<p>The data you provide will be confidential, and no identifying information will be sought. Only group data will be analysed and reported.</p>

<h5>PARTICIPATION:</h5>
<p>Participation of your child in this project is entirely voluntary, and you and your child are free to decline to participate. If you accept the invitation to participate, you will still have the opportunity to withdraw from the project at any stage during. Any associated data will not be used in the project. </p>

      </div>
         <div class="modal-footer">
             <div class="pull-left">
             	 <button id="agree" class="btn-success btn pull-left" type="submit">Agree</button>
             	 <button id="disagree" class="btn btn-danger">Disagree</button>
                 
             </div>
        
        </div>
          </div>
  </div>
</div>
						<input type="hidden" name="_token" value="{{ csrf_token() }}">

						<div class="form-group">
							<label class="col-md-4 control-label">Name</label>
							<div class="col-md-6">
								<input type="text" class="form-control" name="name" value="{{ old('name') }}">
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">E-Mail Address</label>
							<div class="col-md-6">
								<input type="email" class="form-control" name="email" value="{{ old('email') }}">
							</div>
						</div>
<div class="form-group">
							<label class="col-md-4 control-label">Select Character</label>
							<div class="col-md-6">
								<select name="user_image">
										<option value="Bagheera.png">Bagheera</option>
										<option value="Baloo.png">Baloo</option>
										<option value="Blossom.png">Blossom</option>
										<option value="Bubbles">Bubbles</option>
										<option value="Bugs_Bunny.png">Bugs Bunny</option>
										<option value="Buttercup.png">Buttercup</option>
										<option value="CheshireCat.png">Cheshire Cat</option>
										<option value="Chief Wiggum.png">Chief Wiggum</option>
										<option value="Courage dog.png">Courage dog</option>
										<option value="Daffy.png">Daffy</option>
										<option value="Dumbo.png">Dumbo</option>
										<option value="Felix.png">Felix</option>
										<option value="Foghorn Leghorn.png">Foghorn Leghorn</option>
										<option value="Goofy.png">Goofy</option>
										<option value="Hades.png">Hades</option>
										<option value="Him.png">Him</option>
										<option value="Jerry.png">Jerry</option>
										<option value="Lisa Simpson.png">Lisa Simpson</option>
										<option value="Mayor.png">Mayor</option>
										<option value="Mike Wazowski.png">Mike Wazowski</option>
										<option value="Moe Szyslak.png">Moe Szyslak</option>
										<option value="Mojo jojo.png">Mojo jojo</option>
										<option value="Pink Panther.png">Pink Panther</option>
										<option value="Pluto.png">Pluto</option>
										<option value="Porky Pig.png">Porky Pig</option>
								</select> 
								
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-4 control-label">Password</label>
							<div class="col-md-6">
								<input type="password" class="form-control" name="password">
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Confirm Password</label>
							<div class="col-md-6">
								<input type="password" class="form-control" name="password_confirmation">
							</div>
						</div>

						<div class="form-group">
							<div class="col-md-6 col-md-offset-4">
								<button type="button" class="btn btn-primary" id='register_btn'>
									Register
								</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection